// Marks (0-100) -> letter grade and grade points (10-point scale, pass mark 40)
const SCALE = [
  [90, 'O', 10], [80, 'A+', 9], [70, 'A', 8],
  [60, 'B+', 7], [50, 'B', 6], [40, 'C', 5],
];

function grade(marks) {
  for (const [min, letter, points] of SCALE) {
    if (marks >= min) return { letter, points };
  }
  return { letter: 'F', points: 0 };
}

module.exports = { grade, PASS_MARK: 40 };
