const str = (v) => String(v ?? '').trim();

function studentErrors(b) {
  const e = [];
  if (!str(b.enrollment_no)) e.push('Enrollment number is required.');
  if (!str(b.name)) e.push('Name is required.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str(b.email))) e.push('Enter a valid email address.');
  if (str(b.phone) && !/^[0-9+\-\s]{7,15}$/.test(str(b.phone))) e.push('Phone must be 7-15 digits.');
  if (!str(b.branch)) e.push('Branch is required.');
  const sem = Number(b.semester);
  if (!Number.isInteger(sem) || sem < 1 || sem > 8) e.push('Semester must be between 1 and 8.');
  return e;
}

function courseErrors(b) {
  const e = [];
  if (!str(b.code)) e.push('Course code is required.');
  if (!str(b.title)) e.push('Course title is required.');
  const cr = Number(b.credits);
  if (!Number.isInteger(cr) || cr < 1 || cr > 6) e.push('Credits must be between 1 and 6.');
  return e;
}

function marksError(m) {
  const n = Number(m);
  return m === '' || m === null || Number.isNaN(n) || n < 0 || n > 100
    ? 'Marks must be a number between 0 and 100.' : null;
}

module.exports = { str, studentErrors, courseErrors, marksError };
