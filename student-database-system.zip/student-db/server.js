const express = require('express');
const path = require('path');
require('./db'); // creates tables on first run

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/students', require('./routes/students'));
app.use('/api/courses', require('./routes/courses'));
app.use('/api/results', require('./routes/results'));
app.use('/api/stats', require('./routes/stats'));

app.use('/api', (req, res) => res.status(404).json({ error: 'Route not found.' }));

// Central error handler: turns DB constraint failures into readable messages
app.use((err, req, res, next) => {
  if (err.code && err.code.startsWith('SQLITE_CONSTRAINT')) {
    const msg = err.message.includes('UNIQUE')
      ? 'That enrollment number, email or course code already exists.'
      : 'The data breaks a database rule. Check the values and try again.';
    return res.status(409).json({ error: msg });
  }
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Student database running at http://localhost:${PORT}`));
