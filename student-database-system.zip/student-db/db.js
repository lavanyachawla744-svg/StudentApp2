const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const dir = path.join(__dirname, 'data');
fs.mkdirSync(dir, { recursive: true });

const db = new Database(path.join(dir, 'students.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS students (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  enrollment_no TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  phone         TEXT,
  branch        TEXT NOT NULL,
  semester      INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
  batch         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS courses (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  code    TEXT NOT NULL UNIQUE,
  title   TEXT NOT NULL,
  credits INTEGER NOT NULL CHECK (credits BETWEEN 1 AND 6)
);

CREATE TABLE IF NOT EXISTS results (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  course_id  INTEGER NOT NULL REFERENCES courses(id)  ON DELETE CASCADE,
  marks      REAL    NOT NULL CHECK (marks BETWEEN 0 AND 100),
  UNIQUE (student_id, course_id)
);

-- Credit-weighted CGPA on a 10-point scale, computed by the database.
CREATE VIEW IF NOT EXISTS student_cgpa AS
SELECT r.student_id,
       COUNT(*) AS subjects,
       ROUND(SUM(
         CASE WHEN r.marks >= 90 THEN 10 WHEN r.marks >= 80 THEN 9
              WHEN r.marks >= 70 THEN 8  WHEN r.marks >= 60 THEN 7
              WHEN r.marks >= 50 THEN 6  WHEN r.marks >= 40 THEN 5 ELSE 0 END
         * c.credits) * 1.0 / SUM(c.credits), 2) AS cgpa
FROM results r JOIN courses c ON c.id = r.course_id
GROUP BY r.student_id;
`);

module.exports = db;
