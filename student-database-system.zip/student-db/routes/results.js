const router = require('express').Router();
const db = require('../db');

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM results WHERE id = ?').run(req.params.id);
  if (!info.changes) return res.status(404).json({ error: 'Result not found.' });
  res.status(204).end();
});

module.exports = router;
