const router = require('express').Router();
const db = require('../db');
const { grade } = require('../utils/grade');
const { str, studentErrors, marksError } = require('../utils/validate');

const BASE = `SELECT s.*, COALESCE(g.subjects, 0) AS subjects, g.cgpa
              FROM students s LEFT JOIN student_cgpa g ON g.student_id = s.id`;

// GET /api/students?search=&branch=&semester=&sort=&order=
function listStudents(query) {
  const { search = '', branch = '', semester = '', sort = 'name', order = 'asc' } = query;
  const where = [], params = [];
  if (search) {
    where.push('(s.name LIKE ? OR s.enrollment_no LIKE ? OR s.email LIKE ?)');
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (branch)   { where.push('s.branch = ?');   params.push(branch); }
  if (semester) { where.push('s.semester = ?'); params.push(Number(semester)); }
  const col = { name: 's.name', enrollment_no: 's.enrollment_no', semester: 's.semester', cgpa: 'g.cgpa' }[sort] || 's.name';
  const dir = order === 'desc' ? 'DESC' : 'ASC';
  const sql = `${BASE} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${col} ${dir}`;
  return db.prepare(sql).all(...params);
}

router.get('/', (req, res) => res.json(listStudents(req.query)));

router.get('/export.csv', (req, res) => {
  const rows = listStudents(req.query);
  const head = ['enrollment_no', 'name', 'email', 'phone', 'branch', 'semester', 'batch', 'subjects', 'cgpa'];
  const cell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csv = [head.join(','), ...rows.map((r) => head.map((h) => cell(r[h])).join(','))].join('\n');
  res.set({ 'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename="students.csv"' });
  res.send(csv);
});

router.get('/:id', (req, res) => {
  const student = db.prepare(`${BASE} WHERE s.id = ?`).get(req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found.' });
  const results = db.prepare(
    `SELECT r.id, r.marks, c.id AS course_id, c.code, c.title, c.credits
     FROM results r JOIN courses c ON c.id = r.course_id
     WHERE r.student_id = ? ORDER BY c.code`).all(req.params.id)
    .map((r) => ({ ...r, ...grade(r.marks) }));
  res.json({ ...student, results });
});

router.post('/', (req, res) => {
  const errors = studentErrors(req.body);
  if (errors.length) return res.status(400).json({ error: errors.join(' ') });
  const b = req.body;
  const info = db.prepare(
    `INSERT INTO students (enrollment_no, name, email, phone, branch, semester, batch)
     VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(str(b.enrollment_no), str(b.name), str(b.email).toLowerCase(), str(b.phone), str(b.branch), Number(b.semester), str(b.batch));
  res.status(201).json(db.prepare(`${BASE} WHERE s.id = ?`).get(info.lastInsertRowid));
});

router.put('/:id', (req, res) => {
  const errors = studentErrors(req.body);
  if (errors.length) return res.status(400).json({ error: errors.join(' ') });
  const b = req.body;
  const info = db.prepare(
    `UPDATE students SET enrollment_no=?, name=?, email=?, phone=?, branch=?, semester=?, batch=? WHERE id=?`)
    .run(str(b.enrollment_no), str(b.name), str(b.email).toLowerCase(), str(b.phone), str(b.branch), Number(b.semester), str(b.batch), req.params.id);
  if (!info.changes) return res.status(404).json({ error: 'Student not found.' });
  res.json(db.prepare(`${BASE} WHERE s.id = ?`).get(req.params.id));
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM students WHERE id = ?').run(req.params.id);
  if (!info.changes) return res.status(404).json({ error: 'Student not found.' });
  res.status(204).end();
});

// Add or update a result for a student (one result per course)
router.post('/:id/results', (req, res) => {
  const { course_id, marks } = req.body;
  const err = marksError(marks);
  if (err) return res.status(400).json({ error: err });
  if (!db.prepare('SELECT 1 FROM students WHERE id = ?').get(req.params.id)) return res.status(404).json({ error: 'Student not found.' });
  if (!db.prepare('SELECT 1 FROM courses WHERE id = ?').get(course_id)) return res.status(400).json({ error: 'Choose a valid course.' });
  db.prepare(`INSERT INTO results (student_id, course_id, marks) VALUES (?, ?, ?)
              ON CONFLICT(student_id, course_id) DO UPDATE SET marks = excluded.marks`)
    .run(req.params.id, course_id, Number(marks));
  res.status(201).json({ ok: true });
});

module.exports = router;
