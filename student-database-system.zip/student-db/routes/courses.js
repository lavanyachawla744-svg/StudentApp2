const router = require('express').Router();
const db = require('../db');
const { str, courseErrors } = require('../utils/validate');

router.get('/', (req, res) => {
  res.json(db.prepare(
    `SELECT c.*, COUNT(r.id) AS enrolled, ROUND(AVG(r.marks), 1) AS avg_marks
     FROM courses c LEFT JOIN results r ON r.course_id = c.id
     GROUP BY c.id ORDER BY c.code`).all());
});

router.post('/', (req, res) => {
  const errors = courseErrors(req.body);
  if (errors.length) return res.status(400).json({ error: errors.join(' ') });
  const { code, title, credits } = req.body;
  const info = db.prepare('INSERT INTO courses (code, title, credits) VALUES (?, ?, ?)')
    .run(str(code).toUpperCase(), str(title), Number(credits));
  res.status(201).json(db.prepare('SELECT * FROM courses WHERE id = ?').get(info.lastInsertRowid));
});

router.put('/:id', (req, res) => {
  const errors = courseErrors(req.body);
  if (errors.length) return res.status(400).json({ error: errors.join(' ') });
  const { code, title, credits } = req.body;
  const info = db.prepare('UPDATE courses SET code=?, title=?, credits=? WHERE id=?')
    .run(str(code).toUpperCase(), str(title), Number(credits), req.params.id);
  if (!info.changes) return res.status(404).json({ error: 'Course not found.' });
  res.json(db.prepare('SELECT * FROM courses WHERE id = ?').get(req.params.id));
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM courses WHERE id = ?').run(req.params.id);
  if (!info.changes) return res.status(404).json({ error: 'Course not found.' });
  res.status(204).end();
});

module.exports = router;
