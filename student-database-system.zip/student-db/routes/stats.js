const router = require('express').Router();
const db = require('../db');
const { grade, PASS_MARK } = require('../utils/grade');

router.get('/', (req, res) => {
  const total = db.prepare('SELECT COUNT(*) n FROM students').get().n;
  const courses = db.prepare('SELECT COUNT(*) n FROM courses').get().n;
  const avgCgpa = db.prepare('SELECT ROUND(AVG(cgpa), 2) v FROM student_cgpa').get().v;
  const byBranch = db.prepare('SELECT branch, COUNT(*) n FROM students GROUP BY branch ORDER BY n DESC').all();
  const top = db.prepare(
    `SELECT s.id, s.name, s.enrollment_no, s.branch, g.cgpa
     FROM student_cgpa g JOIN students s ON s.id = g.student_id
     ORDER BY g.cgpa DESC LIMIT 5`).all();

  const marks = db.prepare('SELECT marks FROM results').all().map((r) => r.marks);
  const dist = { O: 0, 'A+': 0, A: 0, 'B+': 0, B: 0, C: 0, F: 0 };
  marks.forEach((m) => { dist[grade(m).letter]++; });
  const passRate = marks.length ? Math.round((marks.filter((m) => m >= PASS_MARK).length / marks.length) * 100) : null;

  res.json({ total, courses, avgCgpa, byBranch, top, dist, passRate });
});

module.exports = router;
