# Student Database System

A Node.js web app for managing student records, course results and CGPA.
Express REST API, SQLite database (better-sqlite3) and a single-page frontend in plain HTML, CSS and JavaScript.

## Features
- Create, read, update and delete students, with server-side validation
- Course catalogue with credits (CRUD)
- Record marks per student per course; letter grade and credit-weighted CGPA (10-point scale)
- Search by name, enrollment number or email; filter by branch and semester; sort by name or CGPA
- Overview page: totals, average CGPA, pass rate, grade distribution, top performers, students per branch
- CSV export of the current student list
- Parameterised SQL everywhere (no SQL injection) and escaped output (no XSS)

## Run it
```bash
npm install
npm run seed      # optional: loads 10 sample students and 6 courses
npm start         # http://localhost:3000
```
`npm run reset` wipes the database and reseeds it. Set `PORT` to use another port.
Requires Node 18 or newer.

## Project structure
```
server.js          Express app, routing, central error handler
db.js              SQLite connection, schema, student_cgpa view
seed.js            Sample data loader
routes/            students.js, courses.js, results.js, stats.js
utils/             grade.js (grade scale), validate.js (input checks)
public/            index.html, style.css, app.js (frontend)
data/students.db   Created on first run
```

## Database schema
| Table | Columns |
|---|---|
| students | id, enrollment_no (unique), name, email (unique), phone, branch, semester (1-8), batch, created_at |
| courses | id, code (unique), title, credits (1-6) |
| results | id, student_id -> students, course_id -> courses, marks (0-100), unique (student_id, course_id) |

Deleting a student or course cascades to its results. The `student_cgpa` view computes
`SUM(grade_points x credits) / SUM(credits)` for each student.

## Grade scale
| Marks | Grade | Points |
|---|---|---|
| 90-100 | O | 10 |
| 80-89 | A+ | 9 |
| 70-79 | A | 8 |
| 60-69 | B+ | 7 |
| 50-59 | B | 6 |
| 40-49 | C | 5 |
| below 40 | F | 0 |

## API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | /api/students?search=&branch=&semester=&sort=&order= | List and filter students |
| GET | /api/students/export.csv | Download students as CSV |
| GET | /api/students/:id | Student with results and CGPA |
| POST | /api/students | Create student |
| PUT | /api/students/:id | Update student |
| DELETE | /api/students/:id | Delete student |
| POST | /api/students/:id/results | Add or update a result `{course_id, marks}` |
| DELETE | /api/results/:id | Remove a result |
| GET / POST | /api/courses | List or create courses |
| PUT / DELETE | /api/courses/:id | Update or delete a course |
| GET | /api/stats | Dashboard figures |

Errors return JSON `{ "error": "message" }` with 400 (validation), 404 (not found) or 409 (duplicate).

## Ideas to extend
Login with roles (admin, faculty), attendance tracking, per-semester SGPA, PDF report cards, pagination.
