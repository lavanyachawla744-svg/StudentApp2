const $ = (s) => document.querySelector(s);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dlg = $('#dlg');
let courses = [];

async function api(url, method = 'GET', body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed.');
  return data;
}

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2200);
}

/* ---------- tabs ---------- */
document.querySelectorAll('#tabs button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));
function showTab(name) {
  document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
  ['dashboard', 'students', 'courses'].forEach((id) => { $('#' + id).hidden = id !== name; });
  if (name === 'dashboard') loadDashboard();
  if (name === 'students') loadStudents();
  if (name === 'courses') loadCourses();
}

/* ---------- dashboard ---------- */
async function loadDashboard() {
  const s = await api('/api/stats');
  const max = Math.max(1, ...Object.values(s.dist));
  $('#dashboard').innerHTML = `
    <div class="grid">
      <div class="stat"><b>${s.total}</b><span>Students enrolled</span></div>
      <div class="stat"><b>${s.courses}</b><span>Courses offered</span></div>
      <div class="stat"><b>${s.avgCgpa ?? '–'}</b><span>Average CGPA</span></div>
      <div class="stat"><b>${s.passRate == null ? '–' : s.passRate + '%'}</b><span>Subject pass rate</span></div>
    </div>
    <div class="two">
      <div class="panel"><h2>Grade distribution</h2>
        ${Object.entries(s.dist).map(([g, n]) => `
          <div class="row ${g === 'F' ? 'f' : ''}"><span class="lbl">${g}</span>
            <div class="track"><div class="fill" style="width:${(n / max) * 100}%"></div></div>
            <span class="n">${n}</span></div>`).join('')}
      </div>
      <div class="panel"><h2>Top performers</h2>
        ${s.top.length ? `<ul class="list">${s.top.map((t) => `
          <li><span>${esc(t.name)}<br><small>${esc(t.enrollment_no)} · ${esc(t.branch)}</small></span>
          <span class="cgpa">${t.cgpa}</span></li>`).join('')}</ul>` : '<p class="empty">No results entered yet.</p>'}
        <h2 style="margin-top:18px">Students by branch</h2>
        <ul class="list">${s.byBranch.map((b) => `<li><span>${esc(b.branch)}</span><span>${b.n}</span></li>`).join('') || '<li><small>No students yet.</small></li>'}</ul>
      </div>
    </div>`;
}

/* ---------- students ---------- */
function studentQuery() {
  const [sort, order] = $('#sort').value.split('|');
  const p = new URLSearchParams({ search: $('#q').value, branch: $('#fBranch').value, semester: $('#fSem').value, sort, order });
  return p.toString();
}

async function loadStudents() {
  const rows = await api('/api/students?' + studentQuery());
  $('#export').href = '/api/students/export.csv?' + studentQuery();
  // keep filters in sync with the data
  const all = await api('/api/students');
  fillOptions('#fBranch', [...new Set(all.map((s) => s.branch))].sort(), 'All branches');
  fillOptions('#fSem', [...new Set(all.map((s) => s.semester))].sort((a, b) => a - b), 'All semesters');
  $('#studentTable').innerHTML = rows.length ? `
    <thead><tr><th>Enrollment no.</th><th>Name</th><th>Branch</th><th class="num">Sem</th><th class="num">Subjects</th><th class="num">CGPA</th></tr></thead>
    <tbody>${rows.map((s) => `
      <tr class="click" data-id="${s.id}" tabindex="0">
        <td>${esc(s.enrollment_no)}</td><td>${esc(s.name)}</td><td>${esc(s.branch)}</td>
        <td class="num">${s.semester}</td><td class="num">${s.subjects}</td>
        <td class="num cgpa">${s.cgpa ?? '–'}</td></tr>`).join('')}</tbody>`
    : '<tbody><tr><td class="empty">No students match. Add a student or clear the filters.</td></tr></tbody>';
}

function fillOptions(sel, values, label) {
  const el = $(sel), cur = el.value;
  el.innerHTML = `<option value="">${label}</option>` + values.map((v) => `<option value="${esc(v)}">${esc(v)}</option>`).join('');
  el.value = cur;
}

$('#studentTable').addEventListener('click', (e) => { const tr = e.target.closest('tr[data-id]'); if (tr) openStudent(tr.dataset.id); });
$('#studentTable').addEventListener('keydown', (e) => { if (e.key === 'Enter') { const tr = e.target.closest('tr[data-id]'); if (tr) openStudent(tr.dataset.id); } });
['q', 'fBranch', 'fSem', 'sort'].forEach((id) => $('#' + id).addEventListener(id === 'q' ? 'input' : 'change', debounce(loadStudents, 200)));
$('#addStudent').addEventListener('click', () => studentForm());

function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

function studentForm(s = {}) {
  const f = (k, label, type = 'text', cls = '') => `<label class="${cls}">${label}<input name="${k}" type="${type}" value="${esc(s[k])}"></label>`;
  dlg.innerHTML = `<form class="dlg" method="dialog">
    <h2>${s.id ? 'Edit student' : 'Add student'}</h2>
    <div class="fields">
      ${f('enrollment_no', 'Enrollment number')}${f('name', 'Full name')}
      ${f('email', 'Email', 'email')}${f('phone', 'Phone', 'tel')}
      ${f('branch', 'Branch')}${f('semester', 'Semester (1–8)', 'number')}
      ${f('batch', 'Batch (e.g. 2024-28)', 'text', 'full')}
    </div>
    <p class="err" id="err"></p>
    <div class="actions"><button type="button" class="btn ghost" id="cancel">Cancel</button>
      <button class="btn" type="submit">${s.id ? 'Save changes' : 'Add student'}</button></div>
  </form>`;
  dlg.showModal();
  $('#cancel').onclick = () => dlg.close();
  dlg.querySelector('form').onsubmit = async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));
    try {
      await api(s.id ? `/api/students/${s.id}` : '/api/students', s.id ? 'PUT' : 'POST', body);
      dlg.close(); toast(s.id ? 'Changes saved' : 'Student added'); loadStudents();
    } catch (err) { $('#err').textContent = err.message; }
  };
}

async function openStudent(id) {
  const s = await api('/api/students/' + id);
  if (!courses.length) courses = await api('/api/courses');
  const free = courses.filter((c) => !s.results.some((r) => r.course_id === c.id));
  dlg.innerHTML = `<div class="dlg">
    <h2>${esc(s.name)}</h2>
    <div class="meta"><span>${esc(s.enrollment_no)}</span><span>${esc(s.branch)}, semester ${s.semester}</span>
      <span>${esc(s.email)}</span>${s.phone ? `<span>${esc(s.phone)}</span>` : ''}
      <span>CGPA <b class="cgpa">${s.cgpa ?? '–'}</b></span></div>
    ${s.results.length ? `<div class="wrap"><table>
      <thead><tr><th>Code</th><th>Course</th><th class="num">Credits</th><th class="num">Marks</th><th>Grade</th><th></th></tr></thead>
      <tbody>${s.results.map((r) => `<tr><td>${esc(r.code)}</td><td>${esc(r.title)}</td><td class="num">${r.credits}</td>
        <td class="num">${r.marks}</td><td><span class="grade ${r.letter === 'F' ? 'F' : ''}">${r.letter}</span></td>
        <td><button class="btn small danger" data-del="${r.id}">Remove</button></td></tr>`).join('')}</tbody></table></div>`
      : '<p class="empty">No results yet. Add the first one below.</p>'}
    ${free.length ? `<form class="add" id="addRes">
      <select name="course_id" aria-label="Course">${free.map((c) => `<option value="${c.id}">${esc(c.code)} – ${esc(c.title)}</option>`).join('')}</select>
      <input name="marks" type="number" min="0" max="100" step="0.5" placeholder="Marks" aria-label="Marks out of 100" required>
      <button class="btn" type="submit">Add result</button></form>` : ''}
    <p class="err" id="err"></p>
    <div class="actions">
      <button class="btn danger" id="del">Delete student</button>
      <button class="btn ghost" id="edit">Edit details</button>
      <button class="btn" id="close">Close</button></div>
  </div>`;
  if (!dlg.open) dlg.showModal();
  $('#close').onclick = () => { dlg.close(); loadStudents(); };
  $('#edit').onclick = () => studentForm(s);
  $('#del').onclick = async () => {
    if (!confirm(`Delete ${s.name} and all their results?`)) return;
    await api('/api/students/' + id, 'DELETE'); dlg.close(); toast('Student deleted'); loadStudents();
  };
  dlg.querySelectorAll('[data-del]').forEach((b) => b.onclick = async () => {
    await api('/api/results/' + b.dataset.del, 'DELETE'); openStudent(id);
  });
  const form = $('#addRes');
  if (form) form.onsubmit = async (e) => {
    e.preventDefault();
    try { await api(`/api/students/${id}/results`, 'POST', Object.fromEntries(new FormData(form))); openStudent(id); }
    catch (err) { $('#err').textContent = err.message; }
  };
}

/* ---------- courses ---------- */
async function loadCourses() {
  courses = await api('/api/courses');
  $('#courseTable').innerHTML = courses.length ? `
    <thead><tr><th>Code</th><th>Title</th><th class="num">Credits</th><th class="num">Students</th><th class="num">Avg marks</th><th></th></tr></thead>
    <tbody>${courses.map((c) => `<tr><td>${esc(c.code)}</td><td>${esc(c.title)}</td><td class="num">${c.credits}</td>
      <td class="num">${c.enrolled}</td><td class="num">${c.avg_marks ?? '–'}</td>
      <td><button class="btn small ghost" data-edit="${c.id}">Edit</button>
          <button class="btn small danger" data-del="${c.id}">Delete</button></td></tr>`).join('')}</tbody>`
    : '<tbody><tr><td class="empty">No courses yet. Add one to start recording results.</td></tr></tbody>';
}
$('#courseTable').addEventListener('click', async (e) => {
  const ed = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]');
  if (ed) courseForm(courses.find((c) => c.id == ed.dataset.edit));
  if (del && confirm('Delete this course and every result recorded for it?')) {
    await api('/api/courses/' + del.dataset.del, 'DELETE'); toast('Course deleted'); loadCourses();
  }
});
$('#addCourse').addEventListener('click', () => courseForm());

function courseForm(c = {}) {
  const f = (k, label, type = 'text') => `<label>${label}<input name="${k}" type="${type}" value="${esc(c[k])}"></label>`;
  dlg.innerHTML = `<form class="dlg" method="dialog"><h2>${c.id ? 'Edit course' : 'Add course'}</h2>
    <div class="fields">${f('code', 'Course code')}${f('credits', 'Credits (1–6)', 'number')}
      <label class="full">Title<input name="title" value="${esc(c.title)}"></label></div>
    <p class="err" id="err"></p>
    <div class="actions"><button type="button" class="btn ghost" id="cancel">Cancel</button>
      <button class="btn" type="submit">${c.id ? 'Save changes' : 'Add course'}</button></div></form>`;
  dlg.showModal();
  $('#cancel').onclick = () => dlg.close();
  dlg.querySelector('form').onsubmit = async (e) => {
    e.preventDefault();
    try {
      await api(c.id ? `/api/courses/${c.id}` : '/api/courses', c.id ? 'PUT' : 'POST', Object.fromEntries(new FormData(e.target)));
      dlg.close(); toast(c.id ? 'Changes saved' : 'Course added'); loadCourses();
    } catch (err) { $('#err').textContent = err.message; }
  };
}

loadDashboard();
