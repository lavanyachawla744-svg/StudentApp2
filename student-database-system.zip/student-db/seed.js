// node seed.js          -> adds sample data if the database is empty
// node seed.js --reset  -> wipes everything and reseeds
const db = require('./db');

if (process.argv.includes('--reset')) {
  db.exec('DELETE FROM results; DELETE FROM students; DELETE FROM courses;');
}
if (db.prepare('SELECT COUNT(*) n FROM students').get().n > 0) {
  console.log('Database already has data. Run "npm run reset" to start over.');
  process.exit(0);
}

const courses = [
  ['CS201', 'Data Structures', 4], ['CS202', 'Database Management Systems', 4],
  ['CS203', 'Operating Systems', 3], ['CS204', 'Computer Networks', 3],
  ['MA201', 'Discrete Mathematics', 3], ['HS201', 'Professional Communication', 2],
];
const students = [
  ['240101', 'Aarav Sharma', 'aarav.sharma@example.edu', '9810000001', 'CSE', 3, '2024-28'],
  ['240102', 'Diya Verma', 'diya.verma@example.edu', '9810000002', 'CSE', 3, '2024-28'],
  ['240103', 'Rohan Mehta', 'rohan.mehta@example.edu', '9810000003', 'CSE', 3, '2024-28'],
  ['240104', 'Ishita Rao', 'ishita.rao@example.edu', '9810000004', 'CSE', 3, '2024-28'],
  ['240201', 'Kabir Singh', 'kabir.singh@example.edu', '9810000005', 'ECE', 3, '2024-28'],
  ['240202', 'Meera Nair', 'meera.nair@example.edu', '9810000006', 'ECE', 3, '2024-28'],
  ['240203', 'Vihaan Gupta', 'vihaan.gupta@example.edu', '9810000007', 'ECE', 3, '2024-28'],
  ['240301', 'Anaya Kapoor', 'anaya.kapoor@example.edu', '9810000008', 'ME', 3, '2024-28'],
  ['240302', 'Arjun Reddy', 'arjun.reddy@example.edu', '9810000009', 'ME', 3, '2024-28'],
  ['240401', 'Saanvi Joshi', 'saanvi.joshi@example.edu', '9810000010', 'BBA', 3, '2024-28'],
];

// small deterministic pseudo-random so every seed gives the same data
let seed = 7;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

const insCourse = db.prepare('INSERT INTO courses (code, title, credits) VALUES (?, ?, ?)');
const insStudent = db.prepare(
  'INSERT INTO students (enrollment_no, name, email, phone, branch, semester, batch) VALUES (?, ?, ?, ?, ?, ?, ?)');
const insResult = db.prepare('INSERT INTO results (student_id, course_id, marks) VALUES (?, ?, ?)');

db.transaction(() => {
  const courseIds = courses.map((c) => insCourse.run(...c).lastInsertRowid);
  for (const s of students) {
    const sid = insStudent.run(...s).lastInsertRowid;
    const ability = 48 + rnd() * 42;
    for (const cid of courseIds) {
      const marks = Math.max(25, Math.min(99, Math.round(ability + (rnd() - 0.5) * 24)));
      insResult.run(sid, cid, marks);
    }
  }
})();
console.log(`Seeded ${students.length} students, ${courses.length} courses.`);
